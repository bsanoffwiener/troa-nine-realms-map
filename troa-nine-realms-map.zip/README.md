# TROA THE NINE REALMS Map

This is a map for TROA The Nine Realms server which is a Space Engineers game server. 
Map is built with React Three Fiber.
