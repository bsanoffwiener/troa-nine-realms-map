export const scaleDivider = 250000.0;
