export interface IAsteroids {
    ores: string[];
}
