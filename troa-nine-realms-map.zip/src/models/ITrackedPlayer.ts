export interface ITrackedPlayer {
    Name: string;
    Faction?: string;
    X: number;
    Y: number;
    Z: number;    
}